import React, { useState, useEffect } from 'react';
import { getTokenFromUrl, loginUrl, playSong, pausePlayback, resumePlayback, skipToPosition } from './spotify';

function SpotifyPlayer() {
  const [accessToken, setAccessToken] = useState(null);
  const [songUri, setSongUri] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [position, setPosition] = useState(0);

  useEffect(() => {
    const token = getTokenFromUrl();
    if (token.access_token) {
      setAccessToken(token.access_token);
    }
  }, []);

  const handleLogin = () => {
    window.location.href = loginUrl;
  };

  const handlePlaySong = () => {
    if (accessToken) {
      playSong(accessToken, songUri);
      setIsPlaying(true);
    }
  };

  const handlePausePlayback = () => {
    if (accessToken) {
      pausePlayback(accessToken);
      setIsPlaying(false);
    }
  };

  const handleResumePlayback = () => {
    if (accessToken) {
      resumePlayback(accessToken);
      setIsPlaying(true);
    }
  };

  const handleSkipToPosition = () => {
    if (accessToken) {
      skipToPosition(accessToken, position);
    }
  };

  return (
    <div>
      {accessToken ? (
        <div>
          <input
            type="text"
            value={songUri}
            onChange={(e) => setSongUri(e.target.value)}
            placeholder="Enter song URI"
          />
          <button onClick={handlePlaySong}>Play Song</button>
          <button onClick={handlePausePlayback}>Pause Playback</button>
          <button onClick={handleResumePlayback}>Resume Playback</button>
          <input
            type="number"
            value={position}
            onChange={(e) => setPosition(e.target.value)}
            placeholder="Enter position in milliseconds"
          />
          <button onClick={handleSkipToPosition}>Skip to Position</button>
        </div>
      ) : (
        <button onClick={handleLogin}>Login to Spotify</button>
      )}
    </div>
  );
}

export default SpotifyPlayer;